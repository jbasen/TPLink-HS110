﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronSockets;

namespace TP_Link_HS110
{
	public class HS110
	{
		public delegate void DelegateFn1(SimplSharpString current,						//report readings to Simpl
			SimplSharpString voltage, SimplSharpString power, 
			SimplSharpString total);
		public delegate void DelegateFn2();												//report appliance off
		
		public DelegateFn1 callback_fn1 { set; get; }
		public DelegateFn2 callback_fn2 { set; get; }

		//References
		//https://www.beardmonkey.eu/tplink/hs110/2017/11/21/collect-and-store-realtime-data-from-the-tp-link-hs110.html
		//https://www.softscheck.com/en/reverse-engineering-tp-link-hs110/

		//****************************************************************************************
		// 
		//  HS110	-	Constructor
		// 
		//****************************************************************************************
		public HS110()
		{
		}

		#region Declarations
		private const int buffer_size = 250;											//size of HS110 message receive buffer
		private const string command_string = "{\"emeter\":{\"get_realtime\":{}}}";		//command string sent to HS110
		
		private byte[] fullRequestBytes;
		private string IPAddress;														//IP Address of HS110
		private ushort port;															//Port for communication
		private ushort poll_interval;													//number of seconds between polling operations
		private CTimer cTimer = null;													//timer thread for collecting data 
		private double power;															//power read from HS110

		private bool appliance_off_monitor_enable;										//true of appliance off monitoring is enabled, otherwise false
		private double power_on_threshold;												//minimum power level of appliance to be judged as on
		private double power_off_threshold;												//threshold below which appliance is judged off
		private ushort minimum_on_time_in_seconds;										//time appliance must be on before off trigger is armed
		private ushort dropout_limit;													//max number of dropouts below power_on_threshold
																						//before power on status cancelled
		private ushort dropouts = 0;													//number of dropouts that have occurred
		private CTimer appliance_timer = null;											//timer thread for monitoring appliance activity
		private bool appliance_timer_running = false;									//true while appliance timer is running
		private bool appliance_timer_finished = false;									//true if power stays high for entire time timer is running
		#endregion

		//****************************************************************************************
		// 
		//  Initialization	-	
		// 
		//****************************************************************************************
		public void Initialization(string IPAddress, ushort port, ushort poll_interval, ushort appliance_off_monitor_enable,
			string power_on_threshold, string power_off_threshold, ushort minimum_on_time, ushort dropout_limit)
		{
			byte prev;
			byte[] command_bytes;
			byte[] encrypted_emeter_cmd;
			byte[] header;

			CrestronConsole.PrintLine("HS110 - Connect - {0}, {1}, {2}", IPAddress, port, command_string);

			//save connection info to globals
			#region save parameters
			this.IPAddress = IPAddress;
			this.port = port;
			this.poll_interval = poll_interval;
			if (appliance_off_monitor_enable == 1)
			{
				this.appliance_off_monitor_enable = true;
			}
			else
			{
				this.appliance_off_monitor_enable = false;
			}
			this.power_on_threshold = double.Parse(power_on_threshold);
			this.power_off_threshold = double.Parse(power_off_threshold);
			this.minimum_on_time_in_seconds = minimum_on_time;
			this.dropout_limit = dropout_limit;
			#endregion

			#region Initialize Globals
			appliance_timer_running = false;
			appliance_timer_finished = false;
			#endregion

			#region Encryption
			prev = 171;															//initial encryption key
			
			//convert string to byte array
			command_bytes = new byte[command_string.Length];
			command_bytes = Encoding.ASCII.GetBytes(command_string);

			//encrypt
			encrypted_emeter_cmd = new byte[command_string.Length];
			for (int i = 0; i < command_string.Length; i++)
			{
				encrypted_emeter_cmd[i] = (byte)(command_bytes[i] ^ prev);
				prev = encrypted_emeter_cmd[i];
			}
			
			//create message header
			header = new byte[] { 0, 0, 0, (byte) encrypted_emeter_cmd.Length };
			
			//allocate storage for message 
			fullRequestBytes = new byte[header.Length + encrypted_emeter_cmd.Length];

			//copy header to message
			header.CopyTo(fullRequestBytes, 0);

			//copy encrypted command to message
			encrypted_emeter_cmd.CopyTo(fullRequestBytes, header.Length);
			#endregion

			#region Start Timer to Get Data Every 30 Seconds
			if (cTimer == null)
			{
				try
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Main_Timer_Thread);
					cTimer = new CTimer(Main_Timer_Thread, null, 0, (poll_interval * 1000));
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("HS110-Can't create timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("HS110-Can't create timer thread: " + e + "\n"));
					return;
				}
			}
			else
			{
				try
				{
					//restart timer that was previously stopped
					cTimer.Reset(0, (poll_interval * 1000));
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("HS110-Can't restart timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("HS110-Can't restart timer thread: " + e + "\n"));
					return;
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Main_Timer_Thread	-	
		// 
		//****************************************************************************************
		public void Main_Timer_Thread(Object unused)
		{
			try
			{
				TCPClient client = new TCPClient(IPAddress, port, buffer_size);
				client.ConnectToServerAsync(Connect_Callback);
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("HS110 - Main_Timer_Thread - TCPClient Error" + ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("HS110 - Main_Timer_Thread - TCPClient Error" + ex.ToString());
				return;
			}
		}

		//****************************************************************************************
		// 
		//  Connect_Callback	-	
		// 
		//****************************************************************************************
		private void Connect_Callback(TCPClient client)
		{
			//CrestronConsole.PrintLine("HS110 - Connect_Callback " + client.ClientStatus);

			try
			{
				if (client.ClientStatus == SocketStatus.SOCKET_STATUS_CONNECTED)
				{
					client.SendData(fullRequestBytes, fullRequestBytes.Length);
					client.ReceiveDataAsync(Receive_Callback);
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("HS110 - Connect_Callback - TCPClient Error" + ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("HS110 - Connect_Callback - TCPClient Error" + ex.ToString());

				if (client != null)
				{
					client.DisconnectFromServer();
				}
				return;
			}
		}

		//****************************************************************************************
		// 
		//  Receive_Callback	-	
		// 
		//****************************************************************************************
		void Receive_Callback(TCPClient client, int rxSize)
		{
			double current;														//current read from HS110
			double voltage;														//voltage read from HS110
			double total;														//total value read from HS110
			int err_code;														//error code read from HS110

			//CrestronConsole.PrintLine("HS110 - myReceiveCallback - Received " + rxSize + " bytes");

			try
			{
				if (rxSize > 0)
				{
					#region Decode Received Message
					byte[] result = new byte[rxSize];
					byte prev = 171;
					for (int i = 0; i < rxSize; i++)
					{
						result[i] = (byte)(client.IncomingDataBuffer[i] ^ prev);
						prev = client.IncomingDataBuffer[i];     // Note this line is the difference between encryption and decryption
					}
					#endregion

					#region Parse Data Elements
					string s = System.Text.Encoding.Default.GetString(result, 5, rxSize - 5);//Convert from byte array to string
					//CrestronConsole.PrintLine("HS110 - myReceiveCallback - Decoded = " + s);

					current = Parse_Data_Double(s, "\"current\"", ":", 0);
					voltage = Parse_Data_Double(s, "\"voltage\"", ":", 0);
					power = Parse_Data_Double(s, "\"power\"", ":", 0);
					total = Parse_Data_Double(s, "\"total\"", ":", 0);
					err_code = Parse_Data_Int(s, "\"err_code\"", ":", 0);
					//CrestronConsole.PrintLine("current = " + current + ", voltage = " + voltage + ", power = " + power + ", total = " + total);
					#endregion

					#region Send Data Back to Simpl
					if (callback_fn1 != null)
					{
						if (err_code == 0)
						{
							callback_fn1(current.ToString(), voltage.ToString(), power.ToString(), total.ToString());
						}
						else
						{
							CrestronConsole.PrintLine("HS110 - myReceiveCallback - HS110 Error Code = " + err_code);
							Crestron.SimplSharp.ErrorLog.Error("HS110 - myReceiveCallback - HS110 Error Code = " + err_code);
						}
					}
					#endregion
				
					#region Appliance Monitor
					if ((err_code == 0) && (appliance_off_monitor_enable == true))
					{
						Appliance_Monitor();
					}
					#endregion
				}
				else
				{
					CrestronConsole.PrintLine("HS110 - myReceiveCallback - Zero Bytes Received from HS110");
					Crestron.SimplSharp.ErrorLog.Error("HS110 - myReceiveCallback - Zero Bytes Received from HS110");
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("HS110 - myReceiveCallback - TCPClient Error" + ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("HS110 - myReceiveCallback - TCPClient Error" + ex.ToString());
			}
			finally
			{
				#region Disconnect
				if (client != null)
				{
					client.DisconnectFromServer();
				}
				#endregion
			}
		}
		//****************************************************************************************
		// 
		//  Appliance_Monitor	-	Notify if Appliance Plugged into HS110 turns off
		// 
		//****************************************************************************************
		void Appliance_Monitor()
		{
			if ((power > power_on_threshold) && (appliance_timer_running == false) && (appliance_timer_finished == false))
			{
				#region Start Timer - Power exceeded on threshold
				CrestronConsole.PrintLine("HS110 - Appliance_Monitor - Power exceeded on threshold - power = {0}, appliance_timer_running = {1}, appliance_timer_finished = {2}",
					power, appliance_timer_running, appliance_timer_finished);

				if (appliance_timer == null)
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Appliance_Timer_Callback);//register callback
					appliance_timer = new CTimer(Appliance_Timer_Callback, null, minimum_on_time_in_seconds * 1000);//start timer
				}
				else
				{
					appliance_timer.Reset(minimum_on_time_in_seconds * 1000);	//restart existing timer
				}

				dropouts = 0;													//reset dropouts counter
				appliance_timer_running = true;									//set that timer is running
				appliance_timer_finished = false;								//clear that timer has finished
				#endregion
			}
			else if ((power < power_on_threshold) && (appliance_timer_running == true) && (appliance_timer_finished == false))
			{
				#region Low Power Before Timer Finishes
				dropouts++;														//increment dropouts counter
				CrestronConsole.PrintLine("Dropout Count Incremented, Count = ", dropouts);

				if (dropouts >= dropout_limit)									//has dropouts counter exceeded limit
				{
					CrestronConsole.PrintLine("HS110 - Appliance_Monitor - Low Power Before Timer Finishes - power = {0}, appliance_timer_running = {1}",
						power, appliance_timer_running);
					appliance_timer.Stop();										//stop the timer
					appliance_timer_running = false;							//set that timer not running
					appliance_timer_finished = false;							//make sure timer finished flag is clear
					dropouts = 0;
				}
				#endregion
			}
			else if ((power < power_off_threshold) && (appliance_timer_finished == true))
			{
				#region power dropped below off threshold after power stayed high for longer than timer
				CrestronConsole.PrintLine("HS110 - Appliance_Monitor - Report End of Cycle to Simpl - power = {0}, appliance_timer_finished = {1}",
					power, appliance_timer_finished);
				appliance_timer_finished = false;								//set that timer finished flag is clear

				if (callback_fn2 != null)
				{
					callback_fn2();
				}
				else
				{
					CrestronConsole.PrintLine("HS110 - Appliance_Monitor - End-of-Cycle Callback function not defined");
					Crestron.SimplSharp.ErrorLog.Error("HS110 - Appliance_Monitor - End-of-Cycle Callback function not defined");
				}
				appliance_timer_finished = false;
				#endregion
			}
		}
		//****************************************************************************************
		// 
		//  Appliance_Timer_Callback	-	
		// 
		//****************************************************************************************
		public void Appliance_Timer_Callback(Object unused)
		{
			//if timer expires and power > than power_on_threshold then set flag
			if (power > power_on_threshold)
			{
				appliance_timer.Stop();
				appliance_timer_running = false;
				appliance_timer_finished = true;
			}
		}
		//****************************************************************************************
		// 
		//  Parse_Data_Double	-	Parse Double Data Element from Json
		// 
		//****************************************************************************************
		private double Parse_Data_Double(string s, string id, string data_starting_chars, int start_index)
		{
			int index1;
			int digit_count;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("HS110-Unable to Locate " + id + " in " + s);
				return 0;
			}
			else
			{
				index1 += +id1.Length;
			}

			//get numberr of digits is numerical value
			string s1 = s.Substring(index1);
			digit_count = 0;
			foreach (char c in s1)
			{
				if ((char.IsDigit(c)) || (c == '.'))
				{
					digit_count++;
				}
				else
				{
					break;
				}
			}

			//parse digits
			if (digit_count != 0)
			{
				s1 = s1.Substring(0, digit_count);
				return double.Parse(s1);
			}
			else
			{
				CrestronConsole.PrintLine("HS110-Unable to parse double for " + id + " in " + s);
				return 0;
			}
		}
		//****************************************************************************************
		// 
		//  Parse_Data_Int	-	Parse Integer Data Element from Json
		// 
		//****************************************************************************************
		private int Parse_Data_Int(string s, string id, string data_starting_chars, int start_index)
		{
			int index1;
			int digit_count;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("HS110-Unable to Locate " + id + " in " + s);
				return 0;
			}
			else
			{
				index1 += +id1.Length;
			}

			//get numberr of digits is numerical value
			string s1 = s.Substring(index1);
			digit_count = 0;
			foreach (char c in s1)
			{
				if (char.IsDigit(c))
				{
					digit_count++;
				}
				else
				{
					break;
				}
			}

			//parse digits
			if (digit_count != 0)
			{
				s1 = s1.Substring(0, digit_count);
				return int.Parse(s1);
			}
			else
			{
				CrestronConsole.PrintLine("HS110-Unable to parse int for " + id + " in " + s);
				return 0;
			}
		}

	}
}
