﻿using System.Reflection;

[assembly: AssemblyTitle("TP_Link_HS110")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TP_Link_HS110")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

